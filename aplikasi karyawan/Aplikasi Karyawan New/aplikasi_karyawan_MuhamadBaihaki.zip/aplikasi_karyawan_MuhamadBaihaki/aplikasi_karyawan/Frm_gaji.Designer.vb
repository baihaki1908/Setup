﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_gaji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtig = New System.Windows.Forms.TextBox
        Me.txtpl = New System.Windows.Forms.TextBox
        Me.txtpbket = New System.Windows.Forms.TextBox
        Me.txtpbkes = New System.Windows.Forms.TextBox
        Me.txtul = New System.Windows.Forms.TextBox
        Me.txtt = New System.Windows.Forms.TextBox
        Me.txtgp = New System.Windows.Forms.TextBox
        Me.txtnj = New System.Windows.Forms.TextBox
        Me.txtns = New System.Windows.Forms.TextBox
        Me.txtnor = New System.Windows.Forms.TextBox
        Me.txtnb = New System.Windows.Forms.TextBox
        Me.txttg = New System.Windows.Forms.TextBox
        Me.txtnamar = New System.Windows.Forms.TextBox
        Me.tgl = New System.Windows.Forms.DateTimePicker
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.cmbij = New System.Windows.Forms.ComboBox
        Me.btnk = New System.Windows.Forms.Button
        Me.btnu = New System.Windows.Forms.Button
        Me.btnh = New System.Windows.Forms.Button
        Me.btns = New System.Windows.Forms.Button
        Me.cmbnik = New System.Windows.Forms.ComboBox
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(59, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "No Slip"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(59, 189)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "id jabatan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(379, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Pot BPJS Ket"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(380, 270)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Nama Bank"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(386, 184)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "No Rekening"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(59, 36)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "id Gaji"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(379, 68)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Pot BPJS KES"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(380, 308)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Total Gaji"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(59, 322)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Tunjangan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(59, 114)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(25, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "NIK"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(59, 231)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Nama Jabatan"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(379, 141)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(52, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Pot Lain2"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(380, 224)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 13)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Nama Rekening"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(59, 152)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(43, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Tgl Gaji"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(377, 29)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(71, 13)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Uang Lembur"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(59, 280)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 13)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "Gaji Pokok"
        '
        'txtig
        '
        Me.txtig.Location = New System.Drawing.Point(152, 36)
        Me.txtig.Name = "txtig"
        Me.txtig.Size = New System.Drawing.Size(100, 20)
        Me.txtig.TabIndex = 17
        Me.txtig.Visible = False
        '
        'txtpl
        '
        Me.txtpl.Location = New System.Drawing.Point(470, 141)
        Me.txtpl.Name = "txtpl"
        Me.txtpl.Size = New System.Drawing.Size(100, 20)
        Me.txtpl.TabIndex = 18
        '
        'txtpbket
        '
        Me.txtpbket.Location = New System.Drawing.Point(470, 103)
        Me.txtpbket.Name = "txtpbket"
        Me.txtpbket.Size = New System.Drawing.Size(100, 20)
        Me.txtpbket.TabIndex = 19
        '
        'txtpbkes
        '
        Me.txtpbkes.Location = New System.Drawing.Point(470, 68)
        Me.txtpbkes.Name = "txtpbkes"
        Me.txtpbkes.Size = New System.Drawing.Size(100, 20)
        Me.txtpbkes.TabIndex = 20
        '
        'txtul
        '
        Me.txtul.Location = New System.Drawing.Point(470, 29)
        Me.txtul.Name = "txtul"
        Me.txtul.Size = New System.Drawing.Size(100, 20)
        Me.txtul.TabIndex = 21
        '
        'txtt
        '
        Me.txtt.Location = New System.Drawing.Point(152, 322)
        Me.txtt.Name = "txtt"
        Me.txtt.Size = New System.Drawing.Size(100, 20)
        Me.txtt.TabIndex = 22
        '
        'txtgp
        '
        Me.txtgp.Location = New System.Drawing.Point(152, 280)
        Me.txtgp.Name = "txtgp"
        Me.txtgp.Size = New System.Drawing.Size(100, 20)
        Me.txtgp.TabIndex = 23
        '
        'txtnj
        '
        Me.txtnj.Location = New System.Drawing.Point(152, 231)
        Me.txtnj.Name = "txtnj"
        Me.txtnj.Size = New System.Drawing.Size(100, 20)
        Me.txtnj.TabIndex = 24
        '
        'txtns
        '
        Me.txtns.Location = New System.Drawing.Point(152, 71)
        Me.txtns.Name = "txtns"
        Me.txtns.Size = New System.Drawing.Size(100, 20)
        Me.txtns.TabIndex = 27
        '
        'txtnor
        '
        Me.txtnor.Location = New System.Drawing.Point(470, 181)
        Me.txtnor.Name = "txtnor"
        Me.txtnor.Size = New System.Drawing.Size(100, 20)
        Me.txtnor.TabIndex = 28
        '
        'txtnb
        '
        Me.txtnb.Location = New System.Drawing.Point(470, 263)
        Me.txtnb.Name = "txtnb"
        Me.txtnb.Size = New System.Drawing.Size(100, 20)
        Me.txtnb.TabIndex = 29
        '
        'txttg
        '
        Me.txttg.Location = New System.Drawing.Point(470, 305)
        Me.txttg.Name = "txttg"
        Me.txttg.Size = New System.Drawing.Size(100, 20)
        Me.txttg.TabIndex = 30
        '
        'txtnamar
        '
        Me.txtnamar.Location = New System.Drawing.Point(470, 221)
        Me.txtnamar.Name = "txtnamar"
        Me.txtnamar.Size = New System.Drawing.Size(100, 20)
        Me.txtnamar.TabIndex = 32
        '
        'tgl
        '
        Me.tgl.CustomFormat = "yyyy-MM-dd"
        Me.tgl.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.tgl.Location = New System.Drawing.Point(152, 152)
        Me.tgl.Name = "tgl"
        Me.tgl.Size = New System.Drawing.Size(200, 20)
        Me.tgl.TabIndex = 33
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(23, 425)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(660, 150)
        Me.DataGridView1.TabIndex = 34
        '
        'cmbij
        '
        Me.cmbij.FormattingEnabled = True
        Me.cmbij.Location = New System.Drawing.Point(152, 189)
        Me.cmbij.Name = "cmbij"
        Me.cmbij.Size = New System.Drawing.Size(121, 21)
        Me.cmbij.TabIndex = 35
        '
        'btnk
        '
        Me.btnk.Location = New System.Drawing.Point(458, 375)
        Me.btnk.Name = "btnk"
        Me.btnk.Size = New System.Drawing.Size(75, 23)
        Me.btnk.TabIndex = 39
        Me.btnk.Text = "Keluar"
        Me.btnk.UseVisualStyleBackColor = True
        '
        'btnu
        '
        Me.btnu.Location = New System.Drawing.Point(355, 375)
        Me.btnu.Name = "btnu"
        Me.btnu.Size = New System.Drawing.Size(75, 23)
        Me.btnu.TabIndex = 38
        Me.btnu.Text = "Update"
        Me.btnu.UseVisualStyleBackColor = True
        '
        'btnh
        '
        Me.btnh.Location = New System.Drawing.Point(256, 375)
        Me.btnh.Name = "btnh"
        Me.btnh.Size = New System.Drawing.Size(75, 23)
        Me.btnh.TabIndex = 37
        Me.btnh.Text = "Hapus"
        Me.btnh.UseVisualStyleBackColor = True
        '
        'btns
        '
        Me.btns.Location = New System.Drawing.Point(153, 375)
        Me.btns.Name = "btns"
        Me.btns.Size = New System.Drawing.Size(75, 23)
        Me.btns.TabIndex = 36
        Me.btns.Text = "Simpan"
        Me.btns.UseVisualStyleBackColor = True
        '
        'cmbnik
        '
        Me.cmbnik.FormattingEnabled = True
        Me.cmbnik.Location = New System.Drawing.Point(152, 114)
        Me.cmbnik.Name = "cmbnik"
        Me.cmbnik.Size = New System.Drawing.Size(121, 21)
        Me.cmbnik.TabIndex = 40
        '
        'Frm_gaji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(763, 587)
        Me.Controls.Add(Me.cmbnik)
        Me.Controls.Add(Me.btnk)
        Me.Controls.Add(Me.btnu)
        Me.Controls.Add(Me.btnh)
        Me.Controls.Add(Me.btns)
        Me.Controls.Add(Me.cmbij)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.tgl)
        Me.Controls.Add(Me.txtnamar)
        Me.Controls.Add(Me.txttg)
        Me.Controls.Add(Me.txtnb)
        Me.Controls.Add(Me.txtnor)
        Me.Controls.Add(Me.txtns)
        Me.Controls.Add(Me.txtnj)
        Me.Controls.Add(Me.txtgp)
        Me.Controls.Add(Me.txtt)
        Me.Controls.Add(Me.txtul)
        Me.Controls.Add(Me.txtpbkes)
        Me.Controls.Add(Me.txtpbket)
        Me.Controls.Add(Me.txtpl)
        Me.Controls.Add(Me.txtig)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Frm_gaji"
        Me.Text = "Frm_gaji"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtig As System.Windows.Forms.TextBox
    Friend WithEvents txtpl As System.Windows.Forms.TextBox
    Friend WithEvents txtpbket As System.Windows.Forms.TextBox
    Friend WithEvents txtpbkes As System.Windows.Forms.TextBox
    Friend WithEvents txtul As System.Windows.Forms.TextBox
    Friend WithEvents txtt As System.Windows.Forms.TextBox
    Friend WithEvents txtgp As System.Windows.Forms.TextBox
    Friend WithEvents txtnj As System.Windows.Forms.TextBox
    Friend WithEvents txtns As System.Windows.Forms.TextBox
    Friend WithEvents txtnor As System.Windows.Forms.TextBox
    Friend WithEvents txtnb As System.Windows.Forms.TextBox
    Friend WithEvents txttg As System.Windows.Forms.TextBox
    Friend WithEvents txtnamar As System.Windows.Forms.TextBox
    Friend WithEvents tgl As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents cmbij As System.Windows.Forms.ComboBox
    Friend WithEvents btnk As System.Windows.Forms.Button
    Friend WithEvents btnu As System.Windows.Forms.Button
    Friend WithEvents btnh As System.Windows.Forms.Button
    Friend WithEvents btns As System.Windows.Forms.Button
    Friend WithEvents cmbnik As System.Windows.Forms.ComboBox
End Class
